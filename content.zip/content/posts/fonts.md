+++
title = "Fonts"
author = "Gabor Parti"
date = "2032-09-01"
weight = 11
description = ""
categories = []
tags = []
menu = "main:posts"
+++



# Font projects

## The Brill

https://brill.com/page/419382?language=en

## Google Noto

https://www.youtube.com/watch?v=16_NYHUZ1kM