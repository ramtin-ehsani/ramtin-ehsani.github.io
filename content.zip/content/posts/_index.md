+++
title = "Posts"
author = "Gabor Parti"
date = "2022-09-01"
+++

