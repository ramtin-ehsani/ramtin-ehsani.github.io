+++
title = "Research Experience"
author = "Gabor Parti"
date = "2022-09-01"
plotly = "true"
+++

[<i class="fa fa-graduation-cap" aria-hidden="true"></i> **SOAR Lab**](https://soar-lab.github.io/)

>  Researching software engineering to enhance tools and environments for software engineers using data mining, NLP, and machine learning techniques.